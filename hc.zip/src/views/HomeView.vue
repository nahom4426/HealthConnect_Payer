<script setup lang="ts">
</script>

<template>
  <main>
    <p>Hallo</p>
  </main>
</template>
