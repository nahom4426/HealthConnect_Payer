import Coverages from "@/features/product_settings/pages/Coverages.vue";

export default [
	{
		path: '/benefits',
		name: 'Benefits',
		component: Coverages
	}
]