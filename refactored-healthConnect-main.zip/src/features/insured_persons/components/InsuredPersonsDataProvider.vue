<script setup lang="ts">
import { searchInsuredByInstitution } from "../api/insuredPersonsApi";
import { usePagination } from "@/composables/usePagination";
import type { PropType } from "vue";
import { Status } from "@/types/interface";
import { insuredMembers } from "../store/insuredPersonsStore";
import { ref, watch, onMounted, computed } from "vue";
import { debounce } from "@/utils/debounce";
import { removeUndefined } from "@/utils/utils";
import PaginationControls from "@/composables/PaginationControls.vue";

// Props
const props = defineProps({
  auto: {
    type: Boolean,
    default: true,
  },
  institutionId: {
    type: String,
    required: true,
  },
  status: {
    type: String as PropType<Status>,
    // default: Status.ACTIVE,
  },
  search: {
    type: String,
    default: "",
  },
});

const insuredStore = insuredMembers();
const currentPage = ref(1);
const itemsPerPage = ref(25);
const totalPages = ref(1);
const totalItems = ref(0);

// Pagination setup
const pagination = usePagination({
  auto: false,
  cb: async (data: any) => {
    const response = await searchInsuredByInstitution(
      props.institutionId,
      removeUndefined({
        ...data,
        status: props.status,
        search: props.search,
      })
    );

    const paginated = response?.data || response;

    if (paginated?.content) {
      insuredStore.set(paginated.content);
      currentPage.value = paginated.page ?? data.page ?? 1;
      itemsPerPage.value = paginated.size ?? data.limit ?? 25;
      totalPages.value = paginated.totalPages ?? 1;
      totalItems.value = paginated.totalElements ?? paginated.content.length;
    } else {
      insuredStore.set(paginated);
    }

    return paginated;
  },
});

// Handle page navigation
const goToPage = (page: number) => {
  if (pagination.searching.value) {
    pagination.searchPagination.page.value = page;
    pagination.fetchSearch(true, true);
  } else {
    pagination.pagination.page.value = page;
    pagination.fetch(true, true, pagination.paginationOptions.value.cache);
  }
};

// Watch for search changes
watch(
  () => props.search,
  (newSearch) => {
    console.log("Search changed");
    pagination.send();
  }
);

// Auto-fetch on mount
onMounted(() => {
  if (props.search) {
    pagination.search.value = props.search;
  }

  if (props.auto) {
    pagination.send();
  }
});

// Expose to parent
defineExpose({
  refresh: pagination.send,
  currentPage: computed(() => currentPage.value),
  itemsPerPage: computed(() => itemsPerPage.value),
});
</script>

<template>
  <slot
    :insuredMembers="insuredStore.insuredMembers"
    :pending="pagination.pending.value"
    :error="null"
    :search="pagination.search"
    :currentPage="currentPage"
    :itemsPerPage="itemsPerPage"
    :totalPages="totalPages"
    :totalItems="totalItems"
  />

  <PaginationControls
    v-if="totalPages > 1"
    :current-page="currentPage"
    :total-pages="totalPages"
    :total-items="totalItems"
    :pending="pagination.pending.value"
    :next="pagination.next"
    :previous="pagination.previous"
    :go-to-page="goToPage"
    class="mt-4"
  />
</template>