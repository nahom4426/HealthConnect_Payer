<script setup lang="ts">
import { usePagination } from "@/composables/usePagination";
import { payerContracts } from "../store/payerContractStore";
import { watch } from "vue";
import { removeUndefined } from "@/utils/utils";
import { getPayerContracts } from "../../active_payer_contracts/api/payerContractApi";

const props = defineProps({
  auto: {
    type: Boolean,
    default: true
  },
  status: {
    type: String,
    default: "PENDING" // Default status for active contracts
  },
  search: {
    type: String,
    default: ""
  }
});

const store = payerContracts();

const pagination = usePagination({
  store,
  cb: (data) => 
    getPayerContracts(
      removeUndefined({
        ...data,
        status: props.status,
        search: props.search.trim()
      })
    )
});

watch(
  () => props.search,
  () => {
    pagination.send();
  }
);
</script>

<template>
  <slot
    :contracts="store.payerContracts"
    :pending="pagination.pending.value"
    :error="pagination.error.value"
  />
</template>