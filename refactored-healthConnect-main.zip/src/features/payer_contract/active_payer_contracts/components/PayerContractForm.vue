<script setup>
import { useForm } from '@/components/new_form_builder/useForm';
import Form from '@/components/new_form_builder/Form.vue';
import Input from '@/components/new_form_elements/Input.vue';
import Select from '@/components/new_form_elements/Select.vue';
import Textarea from '@/components/new_form_elements/Textarea.vue';
import Button from '@/components/Button.vue';
import {  ref, computed, watch, onMounted } from 'vue';
import { openModal } from '@customizer/modal-x';
import icons from '@/utils/icons';
import InputEmail from '@/components/new_form_elements/InputEmail.vue';
import ModalFormSubmitButton from '@/components/new_form_builder/ModalFormSubmitButton.vue';

const props = defineProps({
  initialData: {
    type: Object ,
    default: () => ({})
  },
  isEdit: {
    type: Boolean,
    default: false
  },
  pending: {
    type: Boolean,
    default: false
  },
  onSubmit: {
    type: Function ,
    required: true
  },
  onCancel: {
    type: Function ,
    required: true
  }
});

// Form data
const providerLogo = ref<File | null>(null);
const providerName = ref('');
const category = ref('');
const telephone = ref('');
const countryCode = ref('+251');
const address = ref('');
const tin = ref('');
const email = ref('');
const memo = ref('');
const previewImage = ref('');

// Initialize form data from props
onMounted(() => {
  if (props.initialData && Object.keys(props.initialData).length > 0) {
    providerName.value = props.initialData.providerName || '';
    category.value = props.initialData.category || '';
    address.value = props.initialData.address1 || '';
    tin.value = props.initialData.tinNumber || '';
    email.value = props.initialData.email || '';
    memo.value = props.initialData.description || props.initialData.memo || '';

    const fullTelephone = props.initialData.telephone || '';
    const possibleCodes = ['+251'];
    const matchedCode = possibleCodes.find(code => fullTelephone.startsWith(code));
    
    if (matchedCode) {
      countryCode.value = matchedCode;
      telephone.value = fullTelephone.slice(matchedCode.length);
    } else {
      // fallback if code isn't matched
      countryCode.value = '+251'; // or default
      telephone.value = fullTelephone;
    }

    // Handle different logo formats
    if (props.initialData.logoBase64) {
      previewImage.value = props.initialData.logoBase64;
    } else if (props.initialData.logoUrl) {
      previewImage.value = props.initialData.logoUrl;
    } else if (props.initialData.logoPath) {
      // Construct the full URL for the logo
      const baseUrl = import.meta.env.VITE_API_URL || 'http://localhost:8080/api';
      previewImage.value = `${baseUrl}/provider/logo/${props.initialData.logoPath}`;
    }
  }
});


// File upload handling
function handleFileUpload(event) {
  const target = event.target ;
  const file = target.files?.[0];
  if (file) {
    providerLogo.value = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      previewImage.value = e.target?.result ;
    };
    reader.readAsDataURL(file);
  }
}

function browseFiles() {
  const fileInput = document.getElementById('file-upload') ;
  fileInput.click();
}

function handleDragOver(event) {
  event.preventDefault();
  (event.currentTarget ).classList.add('border-primary');
}

function handleDragLeave(event) {
  event.preventDefault();
  (event.currentTarget).classList.remove('border-primary');
}

function handleDrop(event) {
  event.preventDefault();
  (event.currentTarget ).classList.remove('border-primary');
  
  if (event.dataTransfer?.files.length) {
    const file = event.dataTransfer.files[0];
    providerLogo.value = file;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      previewImage.value = e.target?.result ;
    };
    reader.readAsDataURL(file);
  }
}

function resetForm() {
  providerLogo.value = null;
  providerName.value = '';
  category.value = '';
  telephone.value = '';
  countryCode.value = '+251';
  address.value = '';
  tin.value = '';
  email.value = '';
  memo.value = '';
  previewImage.value = '';
}

function handleSubmit() {
  // For edit mode, logo might be optional
  if (!props.isEdit && !providerLogo.value) {
    console.error('Provider logo is required for new providers');
    return;
  }

  const formData = {
    providerName: providerName.value,
    category: category.value,
    telephone: `${countryCode.value}${telephone.value}`,
    address: address.value,
    tinNumber: tin.value,
    email: email.value,
    description: memo.value,
    country: 'Ethiopia'
  };

  // Only include logo if it exists (for new providers or if changed)
  if (providerLogo.value) {
    formData.providerLogo = providerLogo.value;
  }

  // If we have a preview image but no new logo file, pass the existing logo data
  if (previewImage.value && !providerLogo.value && props.isEdit) {
    if (props.initialData.logoBase64) {
      formData.logoBase64 = props.initialData.logoBase64;
    } else if (props.initialData.logoPath) {
      formData.logoPath = props.initialData.logoPath;
    }
  }

  props.onSubmit(formData);
}

const categoryOptions = [
  'Insurance Company',
  'Government Agency',
  'Healthcare Provider',
  'Corporate Entity',
  'Non-Profit Organization'
];
</script>

<template>
  <Form
    ref="formEl"
    :inner="false"
    id="provider-form"
    v-slot="{}"
    class="bg-white"
    @submit.prevent="handleSubmit"
  >
    <div class="p-4 space-y-6">
      <!-- Provider Logo -->
      <div class="space-y-2">
        <label class="block text-sm font-medium text-[#75778B]">
          Provider logo <span v-if="!isEdit" class="text-red-500">*</span>
        </label>
      <div 
  @dragover="handleDragOver"
  @dragleave="handleDragLeave"
  @drop="handleDrop"
  class="border-[1px] bg-[#F6F7FA] border-dashed border-[#75778B] rounded-md items-center justify-center p-6 flex flex-col cursor-pointer hover:border-primary"
>
  <div v-if="previewImage" class="mb-4 relative w-full">
    <img :src="previewImage" alt="Logo preview" class="h-20 w-auto object-contain mx-auto" />
  </div>
  
  <div class="flex items-end justify-center mt-2">
    <!-- <div class="text-2xl font-bold text-gray-700">HYATT</div>
    <div class="text-lg text-gray-500 ml-2">WP REGENCY za</div> -->
    <div class="flex items-center ml-4  rounded-md px-3 py-1">
      <button 
        v-if="isEdit"
        type="button" 
        @click="browseFiles"
        class="text-xs font-medium text-white bg-[#02676B] ml-2 py-2 px-3 hover:underline"
      >
        Change Logo
      </button>
    </div>
  </div>

          <template v-if="!previewImage">
            <p class="text-sm text-[#75778B]">Drag your logo file to start uploading</p>
            <p class="text-sm text-[#75778B] mt-1">or</p>
            <button 
              type="button" 
              @click="browseFiles"
              class="mt-2 px-4 py-2 text-sm font-medium text-[#75778B] border border-[#75778B] rounded-md hover:bg-gray-50"
            >
              Browse images
            </button>
          </template>
          <input 
            id="file-upload" 
            type="file" 
            accept="image/*" 
            class="hidden" 
            @change="handleFileUpload"
            :required="!isEdit"
          />
        </div>
      </div>
      
      <!-- Provider Name -->
      <div class="space-y-2">
        <label class="block text-sm font-medium text-[#75778B]">
          Provider Name <span class="text-red-500">*</span>
        </label>
        <Input
          v-model="providerName"
          name="providerName"
          validation="required"
          :attributes="{
            placeholder: 'Enter provider\'s legal name',
            required: true
          }"
        />
      </div>
      
      <!-- Two column layout -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Category -->
        <div class="space-y-2">
          <label class="block text-sm font-medium text-[#75778B]">
            Category <span class="text-red-500">*</span>
          </label>
          <Select
            v-model="category"
            name="category"
            validation="required"
            :options="categoryOptions"
            :attributes="{
              placeholder: 'Select company category',
              required: true
            }"
          />
        </div>
        
        <!-- Phone Number -->
      <div class="space-y-2">
  <label class="block text-sm font-medium text-[#75778B]">
    Phone Number <span class="text-red-500">*</span>
  </label>
  <div class="flex w-full gap-2">
    <Select
      v-model="countryCode"
      name="countryCode"
      :options="['+251']"
      :attributes="{ required: true }"
    />
    <Input
      v-model="telephone"
      name="phoneNumber"
      validation="required"
      :attributes="{
        placeholder: 'Enter phone number',
        class: 'px-8 my-2 bg-[#F9F9FD]',
        required: true
      }"
    />
  </div>
</div>

      </div>
      
      <!-- Two column layout -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Address -->
        <div class="space-y-2">
          <label class="block text-sm font-medium text-[#75778B]">
            Address <span class="text-red-500">*</span>
          </label>
          <Input
            v-model="address"
            name="address"
            validation="required"
            :attributes="{
              placeholder: 'Enter company address',
              required: true
            }"
          />
        </div>
        
        <!-- TIN -->
        <div class="space-y-2">
          <label class="block text-sm font-medium text-[#75778B]">
            TIN <span class="text-red-500">*</span>
          </label>
          <Input
            v-model="tin"
            name="tin"
            validation="required"
            :attributes="{
              placeholder: 'Enter TIN',
              required: true
            }"
          />
        </div>
      </div>
      
      <!-- Admin User -->
      <div class="space-y-2">
        <label class="block text-sm font-medium text-[#75778B]">
          Admin User <span class="text-red-500">*</span>
        </label>
        <InputEmail
          v-model="email"
          name="email"
          validation="required|email"
          :attributes="{
            placeholder: 'Email of the admin user',
            required: true
          }"
        />
      </div>
      
      <!-- Memo -->
      <div class="space-y-2">
        <label class="block text-sm font-medium text-[#75778B]">
          Description
        </label>
        <Textarea
          v-model="memo"
          name="memo"
          :attributes="{
            placeholder: 'Write any description',
            rows: 3
          }"
        />
      </div>
    </div>
    
    <!-- Form Actions -->
    <div class="pt-4 px-6 border-t border-[#DFDEF2] flex justify-end space-x-4">
      <Button
        type="button"
        @click="props.onCancel"
        class="text-[#75778B] px-6 py-4 border-[1px] border-[#75778B] rounded-lg hover:bg-gray-50"
        :disabled="pending"
      >
        Cancel
      </Button>
      <ModalFormSubmitButton
        :pending="pending"
        :btn-text="isEdit ? 'Update Provider' : 'Add Provider'"
        class="bg-[#02676B] hover:bg-[#014F4F] text-white px-6 py-3 border-[#02676B] hover:border-[#014F4F]"
        />

    </div>
  </Form>
</template>

<style scoped>
/* Additional styling for the form */
:deep(.form-control) {
  @apply bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5;
}

:deep(.form-select) {
  @apply bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5;
}

:deep(.form-textarea) {
  @apply bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5;
}
</style>



